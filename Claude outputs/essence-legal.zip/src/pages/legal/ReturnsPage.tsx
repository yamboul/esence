import { Link } from 'react-router-dom';
import { ContactBlock, LegalLayout, List, Section } from './LegalLayout';
import { BUSINESS, LEGAL_ROUTES } from '@/data/business';

export default function ReturnsPage() {
  const { returns } = BUSINESS;

  return (
    <LegalLayout
      title="Cambios, devoluciones y garantía"
      intro="Queremos que quedes feliz con tu compra. Esta política explica tus derechos como consumidor y cómo gestionamos un cambio, una devolución o un reclamo de garantía, conforme al Estatuto del Consumidor (Ley 1480 de 2011)."
    >
      <Section title="1. Derecho de retracto">
        <p>
          Como compraste a distancia, puedes retractarte de la compra dentro de los {returns.desistimientoDays} días
          hábiles siguientes a la entrega del producto. Para que proceda, el producto debe estar sin abrir, sin usar, con
          sus sellos y empaques originales, y con todos sus accesorios.
        </p>
        <p>
          Por tratarse de un producto de uso personal, no podemos recibir perfumes que ya hayan sido abiertos,
          probados o usados, salvo que presenten un defecto de calidad o fallas cubiertas por la garantía.
        </p>
        <p>
          Los costos de transporte de la devolución, en el caso del retracto, corren por cuenta del comprador. Una vez
          recibamos el producto y confirmemos que está en las condiciones indicadas, te devolvemos el dinero por el mismo
          medio de pago, en un plazo máximo de {returns.refundMaxDays} días calendario. El tiempo en que el dinero se
          refleje en tu cuenta depende de tu banco.
        </p>
      </Section>

      <Section title="2. Producto equivocado o dañado">
        <p>
          Si recibes un producto diferente al que pediste, incompleto o con daños, escríbenos dentro de las{' '}
          {returns.damageReportHours} horas siguientes a la entrega con:
        </p>
        <List
          items={[
            'Tu número de pedido y tu nombre.',
            'Fotos del producto, de las etiquetas y del empaque. Si tienes video de la apertura del paquete, mejor.',
          ]}
        />
        <p>
          Si el error es nuestro o el producto llegó dañado, elegimos contigo entre el cambio por el producto correcto o
          la devolución del dinero, y asumimos los costos de envío.
        </p>
      </Section>

      <Section title="3. Garantía legal">
        <p>
          Todos nuestros productos tienen la garantía legal de calidad, idoneidad y seguridad. Si un producto presenta
          un defecto de fábrica o no corresponde a lo ofrecido, puedes solicitar que lo reparemos, lo cambiemos o te
          devolvamos el dinero. La garantía no cubre daños por mal uso, almacenamiento inadecuado (por ejemplo, calor
          extremo o luz directa) ni el desgaste natural del producto.
        </p>
      </Section>

      <Section title="4. Cómo solicitar un cambio, devolución o garantía">
        <List
          items={[
            'Escríbenos por WhatsApp o correo indicando tu número de pedido y qué necesitas.',
            'Revisamos tu caso y te respondemos con los pasos a seguir y la dirección para el envío, si aplica.',
            'Empaca el producto de forma segura, con todo lo que venía en la caja, y envíalo como te indiquemos.',
            'Cuando lo recibamos y lo revisemos, procesamos el cambio o el reembolso.',
          ]}
        />
        <ContactBlock />
      </Section>

      <Section title="5. Reembolsos">
        <p>
          Los reembolsos se hacen por el mismo medio de pago que usaste en la compra. Si pagaste con PSE o con
          transferencia, te pediremos los datos de una cuenta a tu nombre para devolverte el dinero.
        </p>
      </Section>

      <Section title="6. Más información">
        <p>
          Consulta también nuestros{' '}
          <Link to={LEGAL_ROUTES.terms} className="underline underline-offset-2">
            términos y condiciones
          </Link>{' '}
          y la información sobre{' '}
          <Link to={LEGAL_ROUTES.shipping} className="underline underline-offset-2">
            envíos y entregas
          </Link>
          .
        </p>
      </Section>
    </LegalLayout>
  );
}
