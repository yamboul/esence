import { Link } from 'react-router-dom';
import { ContactBlock, LegalLayout, List, Section } from './LegalLayout';
import { BUSINESS, LEGAL_ROUTES } from '@/data/business';

export default function TermsPage() {
  return (
    <LegalLayout
      title="Términos y condiciones"
      intro={`Estos términos regulan el uso del sitio web de ${BUSINESS.brand} y las compras que realices en él. Al comprar en nuestra tienda aceptas estas condiciones.`}
    >
      <Section title="1. Quiénes somos">
        <p>
          {BUSINESS.brand} es una tienda en línea de perfumería ubicada en {BUSINESS.city}, {BUSINESS.country}, a cargo
          de {BUSINESS.owner} ({BUSINESS.legalName}).
        </p>
        {BUSINESS.taxId && <p>Documento o NIT: {BUSINESS.taxId}.</p>}
        <ContactBlock />
      </Section>

      <Section title="2. Uso del sitio">
        <p>
          Debes ser mayor de edad y tener capacidad legal para comprar. Te comprometes a darnos información veraz y a
          usar el sitio de forma lícita, sin intentar afectar su funcionamiento ni la seguridad de otros usuarios.
        </p>
      </Section>

      <Section title="3. Productos y precios">
        <List
          items={[
            'Los precios están expresados en pesos colombianos (COP) y se muestran antes de confirmar el pago, junto con el costo del envío.',
            'Las fotos y descripciones son referenciales. Pueden existir pequeñas variaciones en el empaque o la presentación.',
            'La disponibilidad depende del inventario. Si un producto se agota después de tu pedido, te contactaremos para ofrecerte un cambio o el reembolso total.',
            'Si detectamos un error evidente en un precio, te contactaremos antes de procesar el pedido para que decidas si lo mantienes con el valor correcto.',
          ]}
        />
      </Section>

      <Section title="4. Proceso de compra y pago">
        <p>
          Para comprar, agregas productos al carrito, ingresas tus datos de contacto y entrega, aceptas la política de
          tratamiento de datos y estos términos, y pagas por los medios habilitados en la pasarela de pagos Wompi.
        </p>
        <p>
          Tu pedido queda confirmado cuando el pago es aprobado. Si el pago es rechazado o queda pendiente, el pedido no
          se procesa hasta que se confirme. Los datos de tu tarjeta o cuenta bancaria se ingresan directamente en la
          pasarela y no pasan por nuestros servidores.
        </p>
      </Section>

      <Section title="5. Envíos, cambios y devoluciones">
        <p>
          Las condiciones de despacho y entrega están en la página de{' '}
          <Link to={LEGAL_ROUTES.shipping} className="underline underline-offset-2">
            envíos
          </Link>
          , y los derechos de retracto, cambio y garantía en la página de{' '}
          <Link to={LEGAL_ROUTES.returns} className="underline underline-offset-2">
            cambios y devoluciones
          </Link>
          . Ambas hacen parte de estos términos.
        </p>
      </Section>

      <Section title="6. Tu cuenta">
        <p>
          Si creas una cuenta, eres responsable de mantener la confidencialidad de tu contraseña y de la actividad que
          ocurra con ella. Avísanos si sospechas un uso no autorizado.
        </p>
      </Section>

      <Section title="7. Datos personales">
        <p>
          Tratamos tus datos conforme a nuestra{' '}
          <Link to={LEGAL_ROUTES.privacy} className="underline underline-offset-2">
            política de tratamiento de datos personales
          </Link>
          .
        </p>
      </Section>

      <Section title="8. Propiedad intelectual">
        <p>
          El diseño del sitio, el logo, los textos y las imágenes propias de {BUSINESS.brand} están protegidos y no
          pueden copiarse ni usarse sin nuestra autorización. Las marcas de los perfumes pertenecen a sus respectivos
          titulares y se mencionan solo para identificar los productos que vendemos.
        </p>
      </Section>

      <Section title="9. Responsabilidad">
        <p>
          Hacemos lo posible para que el sitio funcione de forma continua y sin errores, pero no garantizamos que esté
          libre de interrupciones. Esto no limita los derechos que la ley te reconoce como consumidor.
        </p>
      </Section>

      <Section title="10. Peticiones, quejas y reclamos">
        <p>
          Si tienes una petición, queja o reclamo, escríbenos por los canales de contacto y te responderemos lo antes
          posible. También puedes acudir a la Superintendencia de Industria y Comercio (SIC), la autoridad de
          protección al consumidor en Colombia.
        </p>
      </Section>

      <Section title="11. Ley aplicable y cambios">
        <p>
          Estos términos se rigen por las leyes de la República de Colombia. Podemos actualizarlos cuando sea necesario;
          la versión vigente es la publicada en esta página, con su fecha de actualización. Los cambios no afectan los
          pedidos ya confirmados.
        </p>
      </Section>
    </LegalLayout>
  );
}
