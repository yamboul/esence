import { ContactBlock, LegalLayout, List, Section } from './LegalLayout';
import { BUSINESS } from '@/data/business';

export default function ShippingPage() {
  const { shipping, returns } = BUSINESS;

  return (
    <LegalLayout
      title="Envíos y entregas"
      intro={`Enviamos tus perfumes a ${shipping.coverage}. Aquí te explicamos cómo funcionan los despachos, los tiempos y qué hacer cuando recibas tu pedido.`}
    >
      <Section title="1. Cobertura">
        <p>
          Realizamos envíos a {shipping.coverage}. Al ingresar tu dirección en el pago, el sistema te mostrará si podemos
          entregar en tu ciudad y el costo del envío antes de que confirmes la compra.
        </p>
        {shipping.localDelivery && <p>{shipping.localDelivery}</p>}
      </Section>

      <Section title="2. Tiempos de despacho y entrega">
        <List
          items={[
            <>
              <strong className="font-medium text-neutral-900">Despacho:</strong> {shipping.dispatchTime}.
            </>,
            <>
              <strong className="font-medium text-neutral-900">Entrega:</strong> {shipping.deliveryTime}, contados desde
              el despacho.
            </>,
          ]}
        />
        <p>
          Los tiempos son estimados y pueden variar por temporadas de alta demanda, orden público, clima o novedades de
          la transportadora. Te avisaremos si tu pedido se demora más de lo previsto.
        </p>
      </Section>

      <Section title="3. Costo del envío">
        <p>
          El valor del envío se calcula según el destino y se muestra de forma clara antes del pago, sumado al valor de
          tus productos. No hay cobros adicionales después de confirmar la compra.
        </p>
      </Section>

      <Section title="4. Cómo enviamos">
        <p>
          Despachamos con {shipping.carriers}. Cuando tu pedido salga, te compartiremos por WhatsApp o correo la
          información disponible para que puedas hacerle seguimiento.
        </p>
      </Section>

      <Section title="5. Datos de entrega">
        <p>
          Revisa que tu dirección, barrio, ciudad y número de celular estén correctos antes de pagar, porque la
          transportadora te contactará a ese número. Si la dirección es incorrecta o no hay quien reciba, la
          transportadora puede intentar la entrega nuevamente, y los costos de reenvío por datos errados pueden quedar a
          cargo del comprador.
        </p>
      </Section>

      <Section title="6. Cuando recibas tu pedido">
        <List
          items={[
            'Revisa que el empaque y los sellos estén en buen estado antes de aceptar el paquete.',
            'Si notas daños evidentes, anótalo en la guía de entrega o rechaza el paquete y avísanos de inmediato.',
            `Si el producto llega dañado o es diferente al que pediste, escríbenos dentro de las ${returns.damageReportHours} horas siguientes a la entrega con tu número de pedido y fotos del producto y del empaque. Un video al abrir el paquete nos ayuda a resolverlo más rápido.`,
          ]}
        />
        <p>
          En esos casos, nosotros asumimos el costo de envío del cambio o de la devolución. Conoce más en nuestra
          política de cambios y devoluciones.
        </p>
      </Section>

      <Section title="7. ¿Dudas sobre tu envío?">
        <p>Escríbenos y con gusto te ayudamos:</p>
        <ContactBlock />
      </Section>
    </LegalLayout>
  );
}
