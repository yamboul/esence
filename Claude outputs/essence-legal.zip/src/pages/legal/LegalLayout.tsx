import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { BUSINESS, LEGAL_ROUTES } from '@/data/business';

interface LegalLayoutProps {
  title: string;
  intro?: ReactNode;
  children: ReactNode;
}

export function LegalLayout({ title, intro, children }: LegalLayoutProps) {
  useEffect(() => {
    const previous = document.title;
    document.title = `${title} — ${BUSINESS.brand}`;
    return () => {
      document.title = previous;
    };
  }, [title]);

  return (
    <div className="mx-auto w-full max-w-3xl px-6 py-14 md:py-20">
      <nav aria-label="Ruta de navegación" className="mb-8 text-xs uppercase tracking-widest text-neutral-500">
        <Link to="/" className="hover:text-neutral-900">
          Inicio
        </Link>
        <span className="mx-2">/</span>
        <span>{title}</span>
      </nav>

      <h1 className="text-3xl text-neutral-900 md:text-4xl">{title}</h1>
      <p className="mt-3 text-sm text-neutral-500">Última actualización: {BUSINESS.policyDate}</p>

      {intro && <p className="mt-8 text-base leading-relaxed text-neutral-700">{intro}</p>}

      <div className="mt-10 space-y-10">{children}</div>

      <LegalLinks />
    </div>
  );
}

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="text-lg font-medium text-neutral-900">{title}</h2>
      <div className="mt-3 space-y-3 text-[15px] leading-relaxed text-neutral-700">{children}</div>
    </section>
  );
}

export function List({ items }: { items: ReactNode[] }) {
  return (
    <ul className="list-disc space-y-1.5 pl-5">
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
}

export function ContactBlock() {
  return (
    <ul className="space-y-1">
      <li>
        <span className="text-neutral-500">Correo: </span>
        <a className="underline underline-offset-2" href={`mailto:${BUSINESS.email}`}>
          {BUSINESS.email}
        </a>
      </li>
      <li>
        <span className="text-neutral-500">Celular y WhatsApp: </span>
        <a className="underline underline-offset-2" href={`https://wa.me/${BUSINESS.whatsappNumber}`} target="_blank" rel="noopener noreferrer">
          {BUSINESS.phone}
        </a>
      </li>
      <li>
        <span className="text-neutral-500">Ciudad: </span>
        {BUSINESS.city}, {BUSINESS.country}
      </li>
    </ul>
  );
}

function LegalLinks() {
  const links = [
    { to: LEGAL_ROUTES.privacy, label: 'Política de datos' },
    { to: LEGAL_ROUTES.shipping, label: 'Envíos' },
    { to: LEGAL_ROUTES.returns, label: 'Cambios y devoluciones' },
    { to: LEGAL_ROUTES.terms, label: 'Términos y condiciones' },
  ];

  return (
    <nav aria-label="Más información legal" className="mt-16 border-t border-neutral-200 pt-6">
      <ul className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-neutral-600">
        {links.map((link) => (
          <li key={link.to}>
            <Link to={link.to} className="underline-offset-2 hover:text-neutral-900 hover:underline">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
