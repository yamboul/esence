import { ContactBlock, LegalLayout, List, Section } from './LegalLayout';
import { BUSINESS } from '@/data/business';

export default function PrivacyPolicyPage() {
  return (
    <LegalLayout
      title="Política de tratamiento de datos personales"
      intro={
        <>
          En {BUSINESS.brand} cuidamos tu información. Esta política explica qué datos personales recolectamos, para qué
          los usamos, con quién los compartimos y cómo puedes ejercer tus derechos, de acuerdo con la Ley 1581 de 2012,
          sus decretos reglamentarios y demás normas colombianas sobre protección de datos personales.
        </>
      }
    >
      <Section title="1. Responsable del tratamiento">
        <ul className="space-y-1">
          <li>
            <span className="text-neutral-500">Razón social: </span>
            {BUSINESS.legalName} ({BUSINESS.brand})
          </li>
          <li>
            <span className="text-neutral-500">Titular del negocio: </span>
            {BUSINESS.owner}
          </li>
          {BUSINESS.taxId && (
            <li>
              <span className="text-neutral-500">Documento o NIT: </span>
              {BUSINESS.taxId}
            </li>
          )}
          {BUSINESS.address && (
            <li>
              <span className="text-neutral-500">Dirección: </span>
              {BUSINESS.address}
            </li>
          )}
        </ul>
        <ContactBlock />
      </Section>

      <Section title="2. Qué datos recolectamos">
        <p>Recolectamos únicamente los datos necesarios para atender tu compra:</p>
        <List
          items={[
            'Datos de identificación y contacto: nombre, número de celular y correo electrónico.',
            'Datos de entrega: dirección, ciudad y departamento, y las indicaciones que nos dejes para la entrega.',
            'Datos del pedido: productos, valores, fecha, estado del pedido y referencia y estado del pago.',
            'Datos de tu cuenta, si decides crear una: correo electrónico y contraseña. La contraseña se guarda cifrada y nosotros no podemos verla.',
            'Datos técnicos mínimos: el carrito y algunas preferencias se guardan en tu propio navegador para que el sitio funcione.',
          ]}
        />
        <p>
          No almacenamos números de tarjetas ni claves bancarias. Los pagos se realizan directamente en la pasarela de
          pagos y esa información no pasa por nuestros servidores.
        </p>
        <p>
          No solicitamos datos sensibles (como salud, origen racial, orientación sexual o datos biométricos). Nuestras
          ventas están dirigidas a personas mayores de edad y no recolectamos de forma intencional datos de menores.
        </p>
      </Section>

      <Section title="3. Para qué usamos tus datos">
        <List
          items={[
            'Procesar, confirmar, preparar y entregar tus pedidos.',
            'Verificar el estado de tu pago y emitir reembolsos cuando corresponda.',
            'Contactarte por WhatsApp, llamada, mensaje de texto o correo para informarte sobre tu pedido, el envío o cualquier novedad.',
            'Atender consultas, peticiones, quejas, reclamos, garantías y solicitudes de retracto.',
            'Administrar tu cuenta y tu historial de pedidos, si la creaste.',
            'Cumplir obligaciones legales, contables y tributarias, y prevenir fraudes.',
          ]}
        />
        <p>
          Solo te enviaremos promociones o novedades si nos das una autorización aparte para ello, la cual podrás
          retirar cuando quieras.
        </p>
      </Section>

      <Section title="4. Tu autorización">
        <p>
          Al marcar la casilla de aceptación antes de pagar, nos das tu autorización previa, expresa e informada para
          tratar tus datos personales conforme a esta política. Guardamos la fecha y la versión de la política que
          aceptaste como constancia de esa autorización. Si no estás de acuerdo, no podremos procesar el pedido, porque
          necesitamos estos datos para cobrar, preparar y entregar tu compra.
        </p>
      </Section>

      <Section title="5. Con quién compartimos tus datos">
        <p>
          No vendemos tus datos. Solo los compartimos con terceros que nos ayudan a operar la tienda, y únicamente en la
          medida necesaria:
        </p>
        <List
          items={[
            'La pasarela de pagos Wompi, para procesar tu pago.',
            'Transportadoras y servicios de mensajería, para entregar tu pedido.',
            'Proveedores de infraestructura tecnológica donde se almacenan los pedidos (base de datos y alojamiento del sitio).',
            'Herramientas de mensajería que usamos internamente para recibir el aviso de cada pedido.',
            'Autoridades competentes, cuando la ley o una orden judicial lo exija.',
          ]}
        />
        <p>
          Algunos de estos proveedores pueden tener sus servidores fuera de Colombia. Con tu autorización, aceptas que
          tus datos sean transmitidos o transferidos a esos proveedores, quienes deben ofrecer niveles adecuados de
          seguridad y protección de la información.
        </p>
      </Section>

      <Section title="6. Tus derechos como titular">
        <List
          items={[
            'Conocer, actualizar y rectificar tus datos personales.',
            'Solicitar prueba de la autorización que nos diste.',
            'Ser informado sobre el uso que le hemos dado a tus datos.',
            'Revocar la autorización y solicitar la supresión de tus datos cuando no se respeten los principios, derechos y garantías legales, siempre que no exista un deber legal o contractual que nos obligue a conservarlos.',
            'Acceder de forma gratuita a tus datos personales.',
            'Presentar quejas ante la Superintendencia de Industria y Comercio (SIC) por infracciones a la ley, una vez hayas agotado el trámite de consulta o reclamo ante nosotros.',
          ]}
        />
      </Section>

      <Section title="7. Cómo ejercer tus derechos">
        <p>
          Puedes escribirnos o llamarnos por los canales indicados abajo. Para atender tu solicitud necesitamos tu
          nombre, un documento o dato que nos permita identificarte, la descripción clara de lo que pides y un medio
          para responderte.
        </p>
        <ContactBlock />
        <List
          items={[
            'Consultas: las respondemos en máximo 10 días hábiles. Si necesitamos más tiempo, te avisaremos antes de que se cumpla el plazo y podremos tomar hasta 5 días hábiles adicionales.',
            'Reclamos (corrección, actualización o supresión): los atendemos en máximo 15 días hábiles. Si necesitamos más tiempo, te avisaremos y podremos tomar hasta 8 días hábiles adicionales.',
            'Si tu reclamo está incompleto, te pediremos que lo completes dentro de los 5 días siguientes a recibirlo.',
          ]}
        />
      </Section>

      <Section title="8. Seguridad y conservación">
        <p>
          Aplicamos medidas técnicas y organizativas razonables para proteger tus datos contra pérdida, acceso no
          autorizado o uso indebido, y limitamos el acceso a las personas que lo necesitan para atender los pedidos.
        </p>
        <p>
          Conservamos tus datos durante el tiempo necesario para cumplir las finalidades de esta política y los plazos
          que exijan las normas comerciales, contables y tributarias. Después de ese tiempo los eliminamos o los
          anonimizamos.
        </p>
      </Section>

      <Section title="9. Cambios a esta política">
        <p>
          Podemos actualizar esta política cuando sea necesario. La versión vigente siempre estará publicada en esta
          página con su fecha de actualización. Si el cambio afecta de forma importante el uso de tus datos, te lo
          informaremos por un medio visible antes de aplicarlo.
        </p>
        <p className="text-sm text-neutral-500">Versión vigente: {BUSINESS.policyVersion}</p>
      </Section>
    </LegalLayout>
  );
}
