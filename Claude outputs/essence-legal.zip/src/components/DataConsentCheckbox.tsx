import { Link } from 'react-router-dom';
import { LEGAL_ROUTES } from '@/data/business';

interface DataConsentCheckboxProps {
  checked: boolean;
  onChange: (value: boolean) => void;
  /** Pon true cuando el cliente intente pagar sin marcar la casilla. */
  showError?: boolean;
  id?: string;
}

export default function DataConsentCheckbox({
  checked,
  onChange,
  showError = false,
  id = 'data-consent',
}: DataConsentCheckboxProps) {
  const hasError = showError && !checked;

  return (
    <div>
      <label htmlFor={id} className="flex cursor-pointer items-start gap-3 text-sm leading-snug text-neutral-700">
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={(event) => onChange(event.target.checked)}
          aria-required="true"
          aria-invalid={hasError}
          className="mt-0.5 h-4 w-4 shrink-0 accent-black"
        />
        <span>
          He leído y acepto la{' '}
          <Link
            to={LEGAL_ROUTES.privacy}
            target="_blank"
            rel="noopener noreferrer"
            className="underline underline-offset-2"
          >
            política de tratamiento de datos personales
          </Link>{' '}
          y autorizo el tratamiento de mis datos para procesar y entregar mi pedido. También acepto los{' '}
          <Link
            to={LEGAL_ROUTES.terms}
            target="_blank"
            rel="noopener noreferrer"
            className="underline underline-offset-2"
          >
            términos y condiciones
          </Link>
          .
        </span>
      </label>
      {hasError && (
        <p role="alert" className="mt-2 text-xs text-red-600">
          Debes aceptar para poder continuar con el pago.
        </p>
      )}
    </div>
  );
}
