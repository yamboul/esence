# Páginas legales de ESSENCE: cómo integrarlas

## 1. Archivos incluidos (ya van en su carpeta `src/`)

- `src/data/business.ts`: tus datos del negocio. Edítalo aquí y cambia en todas las páginas.
- `src/pages/legal/LegalLayout.tsx`: diseño común de las páginas legales.
- `src/pages/legal/PrivacyPolicyPage.tsx`: política de tratamiento de datos personales.
- `src/pages/legal/ShippingPage.tsx`: envíos y entregas.
- `src/pages/legal/ReturnsPage.tsx`: cambios, devoluciones y garantía.
- `src/pages/legal/TermsPage.tsx`: términos y condiciones.
- `src/components/DataConsentCheckbox.tsx`: casilla de aceptación para el checkout.

## 2. Rutas en `src/App.tsx`

Agrega estos imports junto a los demás:

```tsx
import PrivacyPolicyPage from '@/pages/legal/PrivacyPolicyPage';
import ShippingPage from '@/pages/legal/ShippingPage';
import ReturnsPage from '@/pages/legal/ReturnsPage';
import TermsPage from '@/pages/legal/TermsPage';
```

Y estas rutas dentro de `<Routes>`, antes de la ruta `path="*"`:

```tsx
<Route path="/politica-de-datos" element={<PrivacyPolicyPage />} />
<Route path="/envios" element={<ShippingPage />} />
<Route path="/cambios-y-devoluciones" element={<ReturnsPage />} />
<Route path="/terminos-y-condiciones" element={<TermsPage />} />
```

## 3. Enlaces en el pie de página (`src/components/Footer.tsx`)

```tsx
import { Link } from 'react-router-dom';
import { LEGAL_ROUTES } from '@/data/business';

// dentro del JSX del pie de página:
<ul className="space-y-2 text-sm">
  <li><Link to={LEGAL_ROUTES.privacy}>Política de datos</Link></li>
  <li><Link to={LEGAL_ROUTES.shipping}>Envíos</Link></li>
  <li><Link to={LEGAL_ROUTES.returns}>Cambios y devoluciones</Link></li>
  <li><Link to={LEGAL_ROUTES.terms}>Términos y condiciones</Link></li>
</ul>
```

## 4. Casilla en el checkout (`src/pages/CheckoutPage.tsx`)

```tsx
import DataConsentCheckbox from '@/components/DataConsentCheckbox';
import { BUSINESS } from '@/data/business';

// estados, junto a los demás useState:
const [acceptedData, setAcceptedData] = useState(false);
const [showConsentError, setShowConsentError] = useState(false);

// al inicio de la función que envía el formulario o inicia el pago:
if (!acceptedData) {
  setShowConsentError(true);
  return;
}

// en el JSX, justo encima de los medios de pago:
<DataConsentCheckbox
  checked={acceptedData}
  onChange={setAcceptedData}
  showError={showConsentError}
/>

// en el botón de pagar:
disabled={!acceptedData || loading}   // usa el nombre de tu estado de carga
```

### Guardar la constancia de la autorización (recomendado)

Al crear el pedido, guarda cuándo y qué versión de la política aceptó el cliente:

```ts
data_consent_at: new Date().toISOString(),
data_policy_version: BUSINESS.policyVersion,
```

Y en Supabase, en el editor SQL, si tu tabla de pedidos se llama `orders`:

```sql
alter table orders
  add column if not exists data_consent_at timestamptz,
  add column if not exists data_policy_version text;
```

## 5. Datos que debes confirmar en `src/data/business.ts`

Los marcados con `CONFIRMAR` son valores razonables, pero tienes que validarlos con tu operación real:

- `dispatchTime`: en cuánto despachas después del pago.
- `deliveryTime`: tiempos de entrega por zona.
- `carriers`: transportadoras que usas (puedes poner sus nombres).
- `damageReportHours`: plazo para reportar daños (ahora 48 horas).
- `taxId` y `address`: opcionales; si los llenas, se muestran en las páginas.
- `localDelivery`: opcional, para domicilios locales.

## 6. Aviso importante

Estos textos son un borrador sólido basado en la Ley 1581 de 2012 y la Ley 1480 de 2011, pero no son asesoría legal. Antes de vender, que los revise un abogado, sobre todo la parte de retracto en productos de uso personal y si tu negocio debe inscribir su base de datos en el Registro Nacional de Bases de Datos.
